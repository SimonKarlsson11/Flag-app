För att starta appen, finns det 2st alternativ:

Alternativ 1:
1. gå in i din powershell och gå till rätt folder
2. Skriv "npm run dev"
3. Gå in på address i en webbläsare på din dator

Alternativ 2:
Besök hemsidan: https://astonishing-valkyrie-552888.netlify.app/